function sendMsg()
{
  alert('Sending message');
}